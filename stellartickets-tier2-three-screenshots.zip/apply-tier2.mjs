import { access, readFile, unlink, writeFile } from 'node:fs/promises';

const manifestPath = 'frontend/e2e/screenshots/capture-manifest.ts';
const specPath = 'frontend/e2e/screenshots/capture.spec.ts';
const requiredFiles = [
  'frontend/e2e/screenshots/helpers/install-marketplace-loaded-mocks.ts',
  'frontend/e2e/screenshots/helpers/install-ticket-support-mocks.ts',
  'frontend/src/pages/QRDisplayPage.tsx',
];

await Promise.all(requiredFiles.map((path) => access(path)));

let [manifest, spec] = await Promise.all([
  readFile(manifestPath, 'utf8'),
  readFile(specPath, 'utf8'),
]);

if (!manifest.includes('readonly visibleTexts')) {
  throw new Error('Tier 2 requires the generic Stage 2+ screenshot manifest with visibleTexts support.');
}
if (!spec.includes('capture.visibleTexts')) {
  throw new Error('Tier 2 requires the generic Stage 2+ capture runner.');
}

const captures = [
  {
    id: 'marketplace-listings-loaded-desktop',
    lines: [
      '  {',
      "    id: 'marketplace-listings-loaded-desktop',",
      '    tier: 2,',
      "    page: 'marketplace',",
      "    state: 'listings-loaded',",
      "    route: '/marketplace',",
      "    role: 'guest',",
      "    data: 'seedA',",
      "    version: 'v01',",
      "    viewportName: 'desktop-1440x900',",
      '    viewport: { width: 1440, height: 900 },',
      "    folder: ['02-tier-2-support-flow', 'marketplace'],",
      "    readyText: 'Ticket Marketplace',",
      '    visibleTexts: [',
      "      'Active Listings',",
      "      'Royalties Enforced',",
      "      'On-chain',",
      "      'Midnight Frequency',",
      "      'Builders on Stellar',",
      "      'Indie After Dark',",
      "      'Buy Now',",
      '    ],',
      "    purpose: 'Represents the public desktop secondary marketplace with multiple open resale listings.',",
      "    reviewFocus: 'Review marketplace hierarchy, trust indicators, resale-card consistency, seller and ask-price readability, purchase CTA prominence, desktop density, clipping, and overflow.',",
      '  },',
    ],
  },
  {
    id: 'ticket-detail-ready-mobile',
    lines: [
      '  {',
      "    id: 'ticket-detail-ready-mobile',",
      '    tier: 2,',
      "    page: 'ticket-detail',",
      "    state: 'ready',",
      "    route: '/tickets/ticket-seed-a-01',",
      "    role: 'attendee',",
      "    data: 'seedA',",
      "    version: 'v01',",
      "    viewportName: 'mobile-390x844',",
      '    viewport: { width: 390, height: 844 },',
      "    folder: ['02-tier-2-support-flow', 'ticket-detail'],",
      "    readyText: 'Midnight Frequency',",
      '    visibleTexts: [',
      "      'Active · General Admission',",
      "      'Ticket ID',",
      "      'ticket-seed-a-01',",
      "      'Show QR',",
      "      'View receipt',",
      '    ],',
      "    purpose: 'Represents an authenticated attendee mobile ticket detail with current ownership and its primary actions available.',",
      "    reviewFocus: 'Review ticket identity hierarchy, event date and venue readability, ownership-state language, QR and receipt action prominence, mobile back navigation, clipping, and overflow.',",
      '  },',
    ],
  },
  {
    id: 'qr-display-active-mobile',
    lines: [
      '  {',
      "    id: 'qr-display-active-mobile',",
      '    tier: 2,',
      "    page: 'qr-display',",
      "    state: 'active',",
      "    route: '/tickets/ticket-seed-a-01/qr',",
      "    role: 'attendee',",
      "    data: 'seedA',",
      "    version: 'v01',",
      "    viewportName: 'mobile-390x844',",
      '    viewport: { width: 390, height: 844 },',
      "    folder: ['02-tier-2-support-flow', 'qr-display'],",
      "    readyText: 'Your ticket',",
      '    visibleTexts: [',
      "      'ticket-seed-a-01',",
      "      'Refreshes in',",
      "      'Refresh and revalidate',",
      '    ],',
      "    visibleLabels: ['Active entry QR'],",
      "    purpose: 'Represents the authenticated attendee mobile entry screen with an active rotating ticket QR.',",
      "    reviewFocus: 'Review QR dominance and scanability, ticket identity, countdown and refresh affordance, wallet-address treatment, mobile spacing, warning-strip clearance, clipping, and overflow.',",
      '  },',
    ],
  },
];

const manifestNewline = manifest.includes('\r\n') ? '\r\n' : '\n';
for (const capture of captures) {
  if (manifest.includes(capture.id)) continue;
  const closeMatch = /\r?\n\];\s*$/.exec(manifest);
  if (!closeMatch || closeMatch.index < 0) {
    throw new Error('Could not find the screenshot manifest array terminator.');
  }
  const entry = capture.lines.join(manifestNewline);
  manifest = `${manifest.slice(0, closeMatch.index)}${manifestNewline}${entry}${manifest.slice(closeMatch.index)}`;
}

const specNewline = spec.includes('\r\n') ? '\r\n' : '\n';
const imports = [
  "import { installMarketplaceLoadedMocks } from './helpers/install-marketplace-loaded-mocks';",
  "import { installQrDisplayActiveMocks, installTicketDetailReadyMocks } from './helpers/install-ticket-support-mocks';",
];
for (const importLine of imports) {
  if (spec.includes(importLine)) continue;
  const marker = /import \{ screenshotOutputPath \} from '\.\/helpers\/output-path';\r?\n/;
  const match = spec.match(marker);
  if (!match) throw new Error('Could not find the screenshot output-path import.');
  spec = spec.replace(marker, `${importLine}${specNewline}${match[0]}`);
}

const branches = [
  [captures[0].id, 'installMarketplaceLoadedMocks'],
  [captures[1].id, 'installTicketDetailReadyMocks'],
  [captures[2].id, 'installQrDisplayActiveMocks'],
];
for (const [captureId, installer] of branches) {
  if (spec.includes(`capture.id === '${captureId}'`)) continue;
  const fallback = /\r?\n(\s*)} else \{\r?\n\s*throw new Error\(`No fixture installer exists for screenshot capture: \$\{capture\.id\}`\);/;
  const match = spec.match(fallback);
  if (!match) throw new Error('Could not find the screenshot fixture fallback branch.');
  const indent = match[1];
  spec = spec.replace(
    fallback,
    [
      '',
      `${indent}} else if (capture.id === '${captureId}') {`,
      `${indent}  await ${installer}(page);`,
      `${indent}} else {`,
      `${indent}  throw new Error(\`No fixture installer exists for screenshot capture: \${capture.id}\`);`,
    ].join(specNewline),
  );
}

await Promise.all([
  writeFile(manifestPath, manifest, 'utf8'),
  writeFile(specPath, spec, 'utf8'),
]);
console.log('Tier 2 compact screenshot bundle added: marketplace, ticket detail, and active QR.');
await unlink(new URL(import.meta.url));
