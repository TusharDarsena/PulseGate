import { access, readFile, unlink, writeFile } from 'node:fs/promises';

const manifestPath = 'frontend/e2e/screenshots/capture-manifest.ts';
const specPath = 'frontend/e2e/screenshots/capture.spec.ts';
const helperPath = 'frontend/e2e/screenshots/helpers/install-account-wallet-ready-mocks.ts';

await access(helperPath);

let [manifest, spec] = await Promise.all([
  readFile(manifestPath, 'utf8'),
  readFile(specPath, 'utf8'),
]);

if (!manifest.includes('readonly visibleTexts')) {
  throw new Error('This patch requires the generic Stage 2+ screenshot manifest with visibleTexts support.');
}
if (!spec.includes('capture.visibleTexts')) {
  throw new Error('This patch requires the generic Stage 2+ capture runner.');
}

const manifestNewline = manifest.includes('\r\n') ? '\r\n' : '\n';
const captureId = 'account-wallet-ready-mobile';

if (!manifest.includes(captureId)) {
  const closeMatch = /\r?\n\];\s*$/.exec(manifest);
  if (!closeMatch || closeMatch.index < 0) {
    throw new Error('Could not find the screenshot manifest array terminator.');
  }

  const entry = [
    '  {',
    "    id: 'account-wallet-ready-mobile',",
    '    tier: 2,',
    "    page: 'account',",
    "    state: 'wallet-ready',",
    "    route: '/account',",
    "    role: 'attendee',",
    "    data: 'seedA',",
    "    version: 'v01',",
    "    viewportName: 'mobile-390x844',",
    '    viewport: { width: 390, height: 844 },',
    "    folder: ['02-tier-2-support-flow', 'account'],",
    "    readyText: 'Account',",
    '    visibleTexts: [',
    "      'Signed-in account',",
    "      'attendee@example.test',",
    "      'Ticket wallet',",
    "      'Stellar Testnet',",
    "      'Readiness',",
    "      'ready',",
    "      'GBBE...FZSP',",
    "      'Restore signing on this device',",
    "      'Organizer wallet',",
    "      'Freighter is separate from your ticket wallet.',",
    "      'Connect Freighter',",
    "      'Sign out',",
    '    ],',
    "    purpose: 'Represents the authenticated mobile account surface with a restored attendee wallet and separate organizer-wallet connection controls.',",
    "    reviewFocus: 'Review account-identity hierarchy, attendee wallet network/readiness/address clarity, separation from organizer-wallet controls, recovery and sign-out affordances, mobile spacing, clipping, and fixed-navigation overlap.',",
    '  },',
  ].join(manifestNewline);

  manifest = `${manifest.slice(0, closeMatch.index)}${manifestNewline}${entry}${manifest.slice(closeMatch.index)}`;
}

const specNewline = spec.includes('\r\n') ? '\r\n' : '\n';
const importLine = "import { installAccountWalletReadyMocks } from './helpers/install-account-wallet-ready-mocks';";
if (!spec.includes('installAccountWalletReadyMocks')) {
  const marker = /import \{ screenshotOutputPath \} from '\.\/helpers\/output-path';\r?\n/;
  const match = spec.match(marker);
  if (!match) throw new Error('Could not find the screenshot output-path import.');
  spec = spec.replace(marker, `${importLine}${specNewline}${match[0]}`);
}

if (!spec.includes(`capture.id === '${captureId}'`)) {
  const fallback = /\r?\n(\s*)} else \{\r?\n\s*throw new Error\(`No fixture installer exists for screenshot capture: \$\{capture\.id\}`\);/;
  const match = spec.match(fallback);
  if (!match) throw new Error('Could not find the screenshot fixture fallback branch.');
  const indent = match[1];
  spec = spec.replace(
    fallback,
    [
      '',
      `${indent}} else if (capture.id === '${captureId}') {`,
      `${indent}  await installAccountWalletReadyMocks(page);`,
      `${indent}} else {`,
      `${indent}  throw new Error(\`No fixture installer exists for screenshot capture: \${capture.id}\`);`,
    ].join(specNewline),
  );
}

if (!spec.includes("capture.id === 'account-wallet-ready-mobile') {\n      await page.evaluate")) {
  const stabilizePattern = /^(\s*)await stabilizePage\(page\);\r?$/m;
  const match = spec.match(stabilizePattern);
  if (!match) throw new Error('Could not find the page stabilization call.');
  const indent = match[1];
  spec = spec.replace(
    stabilizePattern,
    [
      match[0],
      `${indent}if (capture.id === 'account-wallet-ready-mobile') {`,
      `${indent}  await page.evaluate(() => window.scrollTo(0, 96));`,
      `${indent}}`,
    ].join(specNewline),
  );
}

await Promise.all([
  writeFile(manifestPath, manifest, 'utf8'),
  writeFile(specPath, spec, 'utf8'),
]);
console.log('Added Tier 2 Account wallet-ready mobile screenshot capture.');
await unlink(new URL(import.meta.url));
