import { access, readFile, unlink, writeFile } from 'node:fs/promises';

const manifestPath = 'frontend/e2e/screenshots/capture-manifest.ts';
const specPath = 'frontend/e2e/screenshots/capture.spec.ts';
const eventDetailHelperPath = 'frontend/e2e/screenshots/helpers/install-event-detail-mocks.ts';
const captureId = 'organizer-event-ready-desktop';

await access(eventDetailHelperPath).catch(() => {
  throw new Error('Stage 8 requires the existing Stage 2 event-detail mock helper.');
});

let [manifest, spec] = await Promise.all([
  readFile(manifestPath, 'utf8'),
  readFile(specPath, 'utf8'),
]);

if (!manifest.includes('readonly visibleTexts')) {
  throw new Error('Stage 8 requires the generic Stage 2+ screenshot manifest with visibleTexts support.');
}
if (!spec.includes('capture.visibleTexts')) {
  throw new Error('Stage 8 requires the generic Stage 2+ capture runner.');
}

const manifestNewline = manifest.includes('\r\n') ? '\r\n' : '\n';
if (!manifest.includes(captureId)) {
  const entry = [
    '  {',
    `    id: '${captureId}',`,
    '    tier: 1,',
    "    page: 'organizer-event',",
    "    state: 'ready',",
    "    route: '/organizer/events/event-seed-a-01',",
    "    role: 'organizer',",
    "    data: 'seedA',",
    "    version: 'v01',",
    "    viewportName: 'desktop-1440x900',",
    '    viewport: { width: 1440, height: 900 },',
    "    folder: ['01-tier-1-core-flow', 'organizer-event'],",
    "    readyText: 'Midnight Frequency',",
    '    visibleTexts: [',
    "      'Confirmed from Stellar',",
    "      'Tickets sold',",
    "      'Sell-through',",
    "      'Gross primary sales',",
    "      'Held in escrow',",
    "      'Organizer tools',",
    "      'Open scanner',",
    "      'Lifecycle actions',",
    "      'Review cancellation',",
    '    ],',
    "    purpose: 'Represents the authenticated organizer desktop management surface for a published event with confirmed Stellar state.',",
    "    reviewFocus: 'Review lifecycle and authority hierarchy, sales and escrow metrics, locked-versus-editable information, scanner access, lifecycle controls, activity visibility, desktop density, clipping, and overflow.',",
    '  },',
  ].join(manifestNewline);
  const closeMatch = /\r?\n\];\s*$/.exec(manifest);
  if (!closeMatch || closeMatch.index < 0) {
    throw new Error('Could not find the screenshot manifest array terminator.');
  }
  manifest = `${manifest.slice(0, closeMatch.index)}${manifestNewline}${entry}${manifest.slice(closeMatch.index)}`;
}

const specNewline = spec.includes('\r\n') ? '\r\n' : '\n';
const importLine = "import { installOrganizerEventReadyMocks } from './helpers/install-organizer-event-mocks';";
if (!spec.includes(importLine)) {
  const marker = /import \{ screenshotOutputPath \} from '\.\/helpers\/output-path';\r?\n/;
  const match = spec.match(marker);
  if (!match) throw new Error('Could not find the screenshot output-path import.');
  spec = spec.replace(marker, `${importLine}${specNewline}${match[0]}`);
}
if (!spec.includes(`capture.id === '${captureId}'`)) {
  const fallback = /\r?\n(\s*)} else \{\r?\n\s*throw new Error\(`No fixture installer exists for screenshot capture: \$\{capture\.id\}`\);/;
  const match = spec.match(fallback);
  if (!match) throw new Error('Could not find the screenshot fixture fallback branch.');
  const indent = match[1];
  spec = spec.replace(
    fallback,
    [
      '',
      `${indent}} else if (capture.id === '${captureId}') {`,
      `${indent}  await installOrganizerEventReadyMocks(page);`,
      `${indent}} else {`,
      `${indent}  throw new Error(\`No fixture installer exists for screenshot capture: \${capture.id}\`);`,
    ].join(specNewline),
  );
}

await Promise.all([
  writeFile(manifestPath, manifest, 'utf8'),
  writeFile(specPath, spec, 'utf8'),
]);
console.log('Stage 8 screenshot capture added.');
await unlink(new URL(import.meta.url));
