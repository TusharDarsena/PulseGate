import { access, readFile, unlink, writeFile } from 'node:fs/promises';

const manifestPath = 'frontend/e2e/screenshots/capture-manifest.ts';
const specPath = 'frontend/e2e/screenshots/capture.spec.ts';
const ticketHelperPath = 'frontend/e2e/screenshots/helpers/install-ticket-detail-mocks.ts';
const callbackHelperPath = 'frontend/e2e/screenshots/helpers/install-auth-callback-mocks.ts';

await Promise.all([
  access(ticketHelperPath),
  access(callbackHelperPath),
]);

let [manifest, spec] = await Promise.all([
  readFile(manifestPath, 'utf8'),
  readFile(specPath, 'utf8'),
]);

if (!manifest.includes('readonly visibleTexts')) {
  throw new Error('This bundle requires the generic Stage 2+ screenshot manifest with visibleTexts support.');
}
if (!spec.includes('capture.visibleTexts')) {
  throw new Error('This bundle requires the generic Stage 2+ capture runner.');
}

const manifestNewline = manifest.includes('\r\n') ? '\r\n' : '\n';
if (!manifest.includes('readonly readyRole?')) {
  const readyTextLine = /^(\s*)readonly readyText: string;\r?$/m;
  const match = manifest.match(readyTextLine);
  if (!match) throw new Error('Could not find readyText in the screenshot manifest interface.');
  manifest = manifest.replace(
    readyTextLine,
    `${match[0]}${manifestNewline}${match[1]}readonly readyRole?: 'heading' | 'alert';`,
  );
}

const captures = [
  {
    id: 'ticket-detail-ready-mobile',
    lines: [
      '  {',
      "    id: 'ticket-detail-ready-mobile',",
      '    tier: 2,',
      "    page: 'ticket-detail',",
      "    state: 'ready',",
      "    route: '/tickets/ticket-seed-a-01',",
      "    role: 'attendee',",
      "    data: 'seedA',",
      "    version: 'v01',",
      "    viewportName: 'mobile-390x844',",
      '    viewport: { width: 390, height: 844 },',
      "    folder: ['02-tier-2-support-flow', 'ticket-detail'],",
      "    readyText: 'Midnight Frequency',",
      '    visibleTexts: [',
      "      'Active · General Admission',",
      "      'Ticket ID',",
      "      'ticket-seed-a-01',",
      "      'Show QR',",
      "      'View receipt',",
      '    ],',
      "    purpose: 'Represents an authenticated attendee mobile ticket detail with current ownership and its primary actions available.',",
      "    reviewFocus: 'Review ticket identity hierarchy, event date and venue readability, ownership-state language, QR and receipt action prominence, mobile back navigation, clipping, and overflow.',",
      '  },',
    ],
  },
  {
    id: 'auth-callback-error-mobile',
    lines: [
      '  {',
      "    id: 'auth-callback-error-mobile',",
      '    tier: 3,',
      "    page: 'auth-callback',",
      "    state: 'error',",
      "    route: '/auth/callback?error_description=The%20sign-in%20link%20is%20invalid%20or%20has%20expired.',",
      "    role: 'guest',",
      "    data: 'seedA',",
      "    version: 'v01',",
      "    viewportName: 'mobile-390x844',",
      '    viewport: { width: 390, height: 844 },',
      "    folder: ['03-tier-3-edge-flow', 'auth-callback'],",
      "    readyText: 'The sign-in link is invalid or has expired.',",
      "    readyRole: 'alert',",
      '    visibleTexts: [',
      "      'The sign-in link is invalid or has expired.',",
      "      'Stellar Testnet',",
      '    ],',
      "    purpose: 'Represents the public mobile authentication callback when the provider returns a visible, recoverable sign-in error.',",
      "    reviewFocus: 'Review callback-error prominence, message clarity, safe unauthenticated shell behavior, mobile centering, Testnet disclosure, clipping, and overflow.',",
      '  },',
    ],
  },
];

for (const capture of captures) {
  if (manifest.includes(capture.id)) continue;
  const closeMatch = /\r?\n\];\s*$/.exec(manifest);
  if (!closeMatch || closeMatch.index < 0) {
    throw new Error('Could not find the screenshot manifest array terminator.');
  }
  const entry = capture.lines.join(manifestNewline);
  manifest = `${manifest.slice(0, closeMatch.index)}${manifestNewline}${entry}${manifest.slice(closeMatch.index)}`;
}

const specNewline = spec.includes('\r\n') ? '\r\n' : '\n';

if (!spec.includes('capture.readyRole')) {
  const readyAssertion = /^(\s*)await expect\(\s*page\.getByRole\('heading',\s*\{\s*name:\s*capture\.readyText\s*\}\),?\s*\)\.toBeVisible\(\);/m;
  const readyMatch = spec.match(readyAssertion);
  if (!readyMatch) {
    throw new Error('Could not find the generic heading readiness assertion.');
  }
  const indent = readyMatch[1];
  spec = spec.replace(
    readyAssertion,
    [
      `${indent}const readyState = capture.readyRole === 'alert'`,
      `${indent}  ? page.getByRole('alert').filter({ hasText: capture.readyText })`,
      `${indent}  : page.getByRole('heading', { name: capture.readyText });`,
      `${indent}await expect(readyState).toBeVisible();`,
    ].join(specNewline),
  );
}

const ticketImport = "import { installTicketDetailReadyMocks } from './helpers/install-ticket-detail-mocks';";
if (!spec.includes('installTicketDetailReadyMocks')) {
  const marker = /import \{ screenshotOutputPath \} from '\.\/helpers\/output-path';\r?\n/;
  const match = spec.match(marker);
  if (!match) throw new Error('Could not find the screenshot output-path import.');
  spec = spec.replace(marker, `${ticketImport}${specNewline}${match[0]}`);
}

const callbackImport = "import { installAuthCallbackErrorMocks } from './helpers/install-auth-callback-mocks';";
if (!spec.includes('installAuthCallbackErrorMocks')) {
  const marker = /import \{ screenshotOutputPath \} from '\.\/helpers\/output-path';\r?\n/;
  const match = spec.match(marker);
  if (!match) throw new Error('Could not find the screenshot output-path import.');
  spec = spec.replace(marker, `${callbackImport}${specNewline}${match[0]}`);
}

const branches = [
  ['ticket-detail-ready-mobile', 'installTicketDetailReadyMocks'],
  ['auth-callback-error-mobile', 'installAuthCallbackErrorMocks'],
];
for (const [captureId, installer] of branches) {
  if (spec.includes(`capture.id === '${captureId}'`)) continue;
  const fallback = /\r?\n(\s*)} else \{\r?\n\s*throw new Error\(`No fixture installer exists for screenshot capture: \$\{capture\.id\}`\);/;
  const match = spec.match(fallback);
  if (!match) throw new Error('Could not find the screenshot fixture fallback branch.');
  const indent = match[1];
  spec = spec.replace(
    fallback,
    [
      '',
      `${indent}} else if (capture.id === '${captureId}') {`,
      `${indent}  await ${installer}(page);`,
      `${indent}} else {`,
      `${indent}  throw new Error(\`No fixture installer exists for screenshot capture: \${capture.id}\`);`,
    ].join(specNewline),
  );
}

await Promise.all([
  writeFile(manifestPath, manifest, 'utf8'),
  writeFile(specPath, spec, 'utf8'),
]);
console.log('Added Tier 2 ticket detail and Tier 3 auth callback screenshot captures.');
await unlink(new URL(import.meta.url));
